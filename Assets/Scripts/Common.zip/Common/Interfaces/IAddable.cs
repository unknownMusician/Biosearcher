namespace Biosearcher.Common.Interfaces
{
    public interface IAddable<T>
    {
        T Add(T a);
    }
}
