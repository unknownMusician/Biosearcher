namespace Biosearcher.Common.Interfaces
{
    public interface ISubtractable<T>
    {
        T Subtract(T s);
    }
}
