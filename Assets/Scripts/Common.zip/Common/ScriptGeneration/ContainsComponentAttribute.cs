﻿using System;

namespace Biosearcher.Common.ScriptGeneration
{
    public sealed class ContainsComponentAttribute : Attribute { }
}
