﻿#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace Biosearcher.Common.ScriptGeneration
{
    public static class ScriptGenerator
    {
        const string ScriptsPath = @"Assets\Scripts";
        const string LogicRelativePath = "Logic";
        const string ComponentsRelativePath = "Components";
        const string AbstractionsRelativePath = "Abstractions";

        [MenuItem("Are You Fruits?/Script Generation/Generate Components")]
        public static void GenerateComponents()
        {
            // EditorUtility.DisplayDialogComplex(
            //     "Generate Components",
            //     "Do you want to generate both Components and Interfaces?",
            //     "Yes, both of them",
            //     "Cancel",
            //     "No, only Components"
            // );

            string logicPath = Path.Combine(ScriptsPath, LogicRelativePath);

            List<string> filePaths = GetAllFilePaths(logicPath);
            filePaths = FilterFilesWithAttribute<ContainsComponentAttribute>(filePaths);
            int createdFilesCount = CreateFiles(filePaths);

            Debug.Log($"Created {createdFilesCount} files.");

            if (createdFilesCount > 0)
            {
                AssetDatabase.Refresh();
            }
        }

        public static int CreateFiles(List<string> filePaths)
        {
            int createdFilesCount = 0;

            string logicPath = Path.Combine(ScriptsPath, LogicRelativePath);
            string componentsPath = Path.Combine(ScriptsPath, ComponentsRelativePath);
            string abstractionsPath = Path.Combine(ScriptsPath, AbstractionsRelativePath);

            if (!Directory.Exists(componentsPath))
            {
                Directory.CreateDirectory(componentsPath);
            }

            if (!Directory.Exists(abstractionsPath))
            {
                Directory.CreateDirectory(abstractionsPath);
            }

            foreach (string filePath in filePaths)
            {
                string componentPath = filePath.Replace(logicPath, componentsPath).Replace(".cs", "Component.cs");
                string abstractionPath = filePath.Replace(logicPath, abstractionsPath);
                int lastSlashIndex = abstractionPath.LastIndexOf('\\');

                abstractionPath = abstractionPath.Substring(0, lastSlashIndex)
                  + "\\I"
                  + abstractionPath.Substring(lastSlashIndex + 1);

                if (!File.Exists(componentPath))
                {
                    using FileStream file = File.Create(componentPath);
                    createdFilesCount++;
                }

                if (!File.Exists(abstractionPath))
                {
                    using FileStream file = File.Create(abstractionPath);
                    createdFilesCount++;
                }
            }

            return createdFilesCount;
        }

        public static List<string> FilterFilesWithAttribute<TAttribute>(List<string> filePaths)
            where TAttribute : Attribute
        {
            string attributeName = typeof(TAttribute).Name;

            if (attributeName.EndsWith("Attribute", StringComparison.Ordinal))
            {
                attributeName = attributeName.Substring(0, attributeName.Length - "Attribute".Length);
            }

            return FilterFilesWithAttribute(filePaths, attributeName);
        }

        public static List<string> FilterFilesWithAttribute(List<string> filePaths, string attributeName)
        {
            var filtered = new List<string>();

            foreach (string filePath in filePaths)
            {
                if (!File.Exists(filePath))
                {
                    throw new Exception($"File \"{filePath}\" does not exist.");
                }

                string fileText = File.ReadAllText(filePath);

                int classTextIndex = fileText.IndexOf("class", StringComparison.Ordinal);

                if (classTextIndex == -1)
                {
                    continue;
                }

                string possibleAttributeText = fileText.Substring(0, classTextIndex);

                int attributeStartIndex = possibleAttributeText.IndexOf('[');
                int attributeEndIndex = possibleAttributeText.LastIndexOf(']');

                if (attributeStartIndex == -1 || attributeEndIndex == -1)
                {
                    continue;
                }

                string attributesText = possibleAttributeText.Substring(
                    attributeStartIndex + 1,
                    attributeEndIndex - attributeStartIndex - 1
                );

                string[] attributes = attributesText.Replace(" ", string.Empty).Replace("][", ",").Split(',');

                if (attributes.Any(a => a == attributeName || a == attributeName + "Attribute"))
                {
                    filtered.Add(filePath);
                }
            }

            return filtered;
        }

        public static List<string> GetAllFilePaths(string directoryPath)
        {
            return GetAllFilePaths(directoryPath, new List<string>());
        }

        public static List<string> GetAllFilePaths(string directoryPath, List<string> filePaths)
        {
            if (!Directory.Exists(directoryPath))
            {
                Debug.LogWarning($"Directory \"{directoryPath}\" does not exist.");

                return filePaths;
            }

            filePaths.AddRange(
                Directory.GetFiles(directoryPath).Where(file => file.EndsWith(".cs", StringComparison.Ordinal))
            );

            foreach (string directory in Directory.GetDirectories(directoryPath))
            {
                GetAllFilePaths(directory, filePaths);
            }

            return filePaths;
        }
    }
}

#endif
